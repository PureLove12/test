# -*- coding: utf-8 -*-
import json
import os
import re
import copy
from typing import Optional, Dict
from datetime import datetime

from logsign.commons.mapper import Mapper
from logsign.integration.cef import CefParser, ParseFailed

from .. import PRODUCT_NAME
from ... import VENDOR_NAME

PREFIX_ID = 4154

fields = {
    'generated_datetime': {'type': 'userdatetime', 'input_format': '%b %d %Y %H:%M:%S'},
    'event_source_ip': {'type': 'ip', 'check_geo': False, 'check_pos': False, 'check_location': False},
    'severity': {'type': 'severity'},
    'system_id': {'type': 'long'},
    'vendor_id': {'type': 'long'},
    'prefix_id': {'type': 'long'},
    'fsize': {'type': 'long'},
    'spt': {'type': 'long'},
    'dpt': {'type': 'long'},
    'Product/Endpoint_IP': {'type': 'ip'},
    'src': {'type': 'ip'},
    'smac': {'type': 'mac'},
    'dst': {'type': 'ip'},
    'LogType': {'type': 'string', 'visible': False}
}

detail_fields = {}

human_readable_fields = {
    "Severity": {
        "ID": "severity.ID",
        "Name": "severity.Name"
    },
    "Destination": {
        "City": "dst.City",
        "Country": "dst.Country",
        "HostName": "destination_hostname",
        "IP": "dst.IP",
        "Domain": "dntdom",
        "UserName": "destination_username",
        "Port": "dpt"
    },
    "Rule": {
        "Name": "SLF_RuleID|Rule",
        "Criteria": "Criteria"
    },
    "URL": {
        "Request": "request"
    },
    "Filter": {
        "Type": "SL_FilterType"
    },
    "Source": {
        "UserName": "META_USER_USER_NAME|suser",
        "City": "Product/Endpoint_IP.City|src.City",
        "Domain": "SLF_DomainName|Domain",
        "Country": "Product/Endpoint_IP.Country|src.Country",
        "HostName": "source_hostname|META_USER_USER_SERVERNAME",
        "IP": "Product/Endpoint_IP.IP|src.IP",
        "Port": "spt",
        "MAC": "smac",
        "OS": "Operating_System",
        "OSVersion": "TMCMdevicePlatform",
        "Command": "Command",
        "PatternNumber": "SLF_PatternNumber",
        "PatternType": "PatternType|SLF_PatternType",
        "PatternVersion": "PatternVersion",
        "Severity": "CLF_ServerityCode",
        "KeyType": "SLF_SourceType"
    },
    "EventMap": {
        "SubType": "event_map_sub_type",
        "Type": "event_map_type",
        "Context": "event_map_context"
    },
    "Details": {
        "VendorID": "signature_id"
    },
    "Time": {
        "Generated": "generated_datetime"
    },
    "Policy": {
        "ID": "Policy",
        "Name": "policy_name|Policy"
    },
    "Mail": {
        "TO": "mail_to",
        "FROM": "mail_from"
    },
    "Risk": {
        "Level": "SLF_CCCA_RiskLevel|SLF_RiskLevel|Risk_Level|Overall_Risk_Rating"
    },
    "Process": {
        "ID": "META_PROCESS_PID",
        "Name": "pname|deviceProcessName|sproc",
        "Path": "ppath",
        "CommandLine": "META_PROCESS_CMD"
    },
    "Object": {
        "SHA2": "META_FILE_SHA2",
        "SHA1": "META_FILE_SHA1",
        "Name": "META_FILE_NAME|fname",
        "Signer": "META_SIGNER",
        "Path": "META_PATH|filePath",
        "Type": "o_type",
        "Size": "fsize",
        "MD5": "META_FILE_MD5",
        "Hash": "fileHash"
    },
    "Signature": {
        "Validation": "META_SIGNER_VALIDATION"
    },
    "EventSource": {
        "Category": "event_source_category",
        "Product": "event_source_product",
        "Vendor": "vendor_name",
        "Version": "EI_ProductVersion|CLF_ProductVersion|device_version",
        "SourceName": "deviceFacility",
        "IP": "event_source_ip.IP",
        "HostName": "dvchost",
        "PrefixID": "prefix_id",
        "Type": "event_source_type"
    },
    "Event": {
        "Info": "name",
        "VendorID": "vendor_id",
        "SubCategory": "cat",
        "RepeatCount": "cnt",
        "Operation": "cnt",
        "Category": "cat",
        "SubType": "Operation",
        "SystemID": "system_id",
        "Channel": "Channel",
        "Action": "Action_on_Message|act|Action|ActionResult",
        "Type": "Event_Type|Filter_Type",
        "Reason": "CLF_ReasonCode",
        "Description": "msg"
    },
    "Device": {
        "ExternalID": "deviceExternalId",
        "Type": "Device_Type",
        "PayloadID": "devicePayloadId"
    },
    "Application": {
        "Version": "Version",
        "Name": "app"
    },
    "Engine": {
        "Version": "EngineVersion|VLF_EngineVersion"
    },
    "Virus": {
        "Name": "VirusName"
    },
    "Scan": {
        "Type": "Scan_Type|SLF_ScanType",
        "Action": "SL_MessageAction"
    },
    "Threat": {
        "Type": "Security_Threat_Type",
        "Name": "NCIE_ThreatName"
    },
    "Operation": {
        "Name": "VLF_FunctionCode"
    },
    "File": {
        "Permissions": "Permission"
    },
    "Traffic": {
        "Direction": "deviceDirection"
    },
    "System": {
        "Action": "VLF_SecondAction"
    },
    "NetworkInformation": {
        "Action": "VLF_SecondAction",
        "ConnectionStatus": "Connection_Status",
    },
    "Pattern": {
        "RuleVersion": "Pattern/Rule_Version",
        "RuleStatus": "Pattern/Rule_Status",
        "RuleID": "Pattern/Rule",
    },
    "CCCA": {
        "Detection": "SLF_CCCA_DetectionSource"
    },
    "Protocol": {
        "Name": "SLF_CCCA_DestinationFormat",
    },
    "Detection": {
        "Type": "DetectionType",
    },
    "Vserver": {
        "Host": "ApexCentralHost",
    },
    "ActiveDirectory": {
        "Domain": "deviceNtDomain"
    },
    "Subject": {
        "AccountName": "Incident_Source_(AD_Account)"
    }
}

data_path = os.path.dirname(__file__) + '/../data'

trendmicro_apex_central_events = {}

data_loss_prevention_events = {}
behavior_monitoring_events = {}
cc_callback_log_events = {}
pattern_update_status_events = {}
content_security_events = {}
spyware_events = {}
virus_events = {}
device_access_control_events = {}
predictive_machine_learning_events = {}
sandbox_detection_events = {}
suspicious_file_events = {}


def load_events():
    global trendmicro_apex_central_events, data_loss_prevention_events, behavior_monitoring_events, \
        cc_callback_log_events, pattern_update_status_events, content_security_events, \
        spyware_events, virus_events, device_access_control_events, predictive_machine_learning_events, \
        sandbox_detection_events, suspicious_file_events, web_security_events

    data_dir = '/opt/logsign-commons/data'

    with open(data_dir + '/trendmicro_apex_central_events.json') as f:
        trendmicro_apex_central_events = json.load(f)

    with open(data_path + '/data_loss_prevention_events.json') as f:
        data_loss_prevention_events = json.load(f)

    with open(data_path + '/behavior_monitoring_events.json') as f:
        behavior_monitoring_events = json.load(f)

    with open(data_path + '/cc_callback_log_events.json') as f:
        cc_callback_log_events = json.load(f)

    with open(data_path + '/pattern_update_status_events.json') as f:
        pattern_update_status_events = json.load(f)

    with open(data_path + '/content_security_events.json') as f:
        content_security_events = json.load(f)

    with open(data_path + '/spyware_events.json') as f:
        spyware_events = json.load(f)

    with open(data_path + '/virus_events.json') as f:
        virus_events = json.load(f)

    with open(data_path + '/device_access_control_events.json') as f:
        device_access_control_events = json.load(f)

    with open(data_path + '/predictive_machine_learning_events.json') as f:
        predictive_machine_learning_events = json.load(f)

    with open(data_path + '/sandbox_detection_events.json') as f:
        sandbox_detection_events = json.load(f)

    with open(data_path + '/suspicious_file_events.json') as f:
        suspicious_file_events = json.load(f)

    with open(data_path + '/web_security_events.json') as f:
        web_security_events = json.load(f)


try:
    load_events()
except:
    pass

replace_list = {
    'Data Loss Prevention': data_loss_prevention_events,
    'Attack Discovery Detections': {'SLF_RiskLevel': {
        'ReplaceColumns': {'0': 'Unknown', '100': 'Low Risk', '500': 'Medium Risk', '1000': 'Hish Risk'}}},
    'Behavior Monitoring': behavior_monitoring_events,
    'Content Security': content_security_events,
    'CnC Callback': cc_callback_log_events,
    'Pattern Update Status': pattern_update_status_events,
    'Spyware': spyware_events,
    'Virus': virus_events,
    'Device Access Control': device_access_control_events,
    'Endpoint Application Control': {
        'Connection_Status': {'ReplaceColumns': {'1': 'Rebuilding database', '2': 'Online', '3': 'Offline'}}},
    'Network Content Inspection': {'SLF_PatternType': {
        'ReplaceColumns': {'0': 'Global C&C pattern', '1': 'Relevance rules', '2': 'User-defined block list'}}},
    'Predictive Machine Learning': predictive_machine_learning_events,
    'Sandbox Detection': sandbox_detection_events,
    'Suspicious File': suspicious_file_events,
    'Web Security': web_security_events
}

key_value_regex = re.compile(r'\"([^"]+)\" : (.*?),(?=/n)')
email_regex = re.compile(r'[^@]+@[^@]+\.[^@]+')
datetime_pattern = re.compile(r'^(\w{3}\s+\d+\s+20\d{2}\s+\d+:[0-5][0-9]:[0-5][0-9])')


def try_to_parse(line, extra_info={}):
    attack_object_logs_list = []

    if 'CEF:' in line:
        parsed_log: Optional['TrendmicroApexCentralLog'] = TrendmicroApexCentralLog(line, extra_info=extra_info)

        for i in range(2, 6):
            label: str = 'cs%dLabel' % i
            label_value: str = 'SLF_ADEObjectGroup_Info_%d' % (i - 1)
            cef_message_part: Dict[str, str] = parsed_log.extension_values

            if label in cef_message_part:
                if cef_message_part[label] != label_value:
                    continue
                copied_parsed_log = copy.deepcopy(parsed_log)
                copied_parsed_log.parse_extra(label_value)
                attack_object_logs_list.append(copied_parsed_log)
        if not attack_object_logs_list:
            return parsed_log
        return attack_object_logs_list


class TrendmicroApexCentralLog(Mapper):
    def __init__(self, line, extra_info={}):
        field_map = (fields, detail_fields, human_readable_fields)
        super(TrendmicroApexCentralLog, self).__init__(field_map, extra_info=extra_info)
        self.line = line
        self.extension_values = None
        self._parse_log()
        self._set_library_columns()
        self._extra_mapping()
        self._apply_exceptions()
        self._set_mandatory_fields()

    def _parse_log(self):
        try:
            cef_line = CefParser('May 19 00:00:00 TM CEF:%s' % self.line.split('CEF:', 1)[1])
            for cef_key, cef_value in cef_line.get().items():
                self.set(cef_key, cef_value)

            self.extension_values = cef_line.get_extension_values()
        except ParseFailed:
            pass

    def parse_extra(self, label_value):
        if self.get(label_value):
            self._parse_extra(self[label_value])

    def _apply_exceptions(self):
        match_datetime = datetime_pattern.match(self.line)
        if match_datetime:
            self.set('generated_datetime', match_datetime.group(0))
        else:
            self.set('generated_datetime', datetime.now())

        try:
            _process = self.get('sproc', self.get('deviceProcessName'))
            path, name = _process.rsplit('\\', 1)
            self.set('pname', name)
            self.set('ppath', path)
            del self['sproc']
            del self['deviceProcessName']
        except:
            pass

        if self.get('LogType', '') == 'Content Security':
            try:
                self.set('Rule', self.get('name'))
                del self['name']
            except:
                pass

        try:
            path, name = self.get('Target', '').rsplit('\\', 1)
            self.set('filePath', path)
            self.set('fname', name)
            del self['Target']
        except:
            pass

        destination_hostname_or_mail_to = self.get('dhost')
        if destination_hostname_or_mail_to:
            match = email_regex.match(destination_hostname_or_mail_to)
            if match:
                self.set('mail_to', destination_hostname_or_mail_to)
            else:
                self.set('destination_hostname', destination_hostname_or_mail_to)

        destination_username_or_mail_to = self.get('duser')
        if destination_username_or_mail_to:
            match = email_regex.match(destination_username_or_mail_to)
            if match and not self.get('mail_to'):
                self.set('mail_to', destination_username_or_mail_to)
            else:
                self.set('destination_username', destination_username_or_mail_to)

        source_hostname_or_mail_from = self.get('shost')
        if source_hostname_or_mail_from:
            match = email_regex.match(source_hostname_or_mail_from)
            if match:
                self.set('mail_from', source_hostname_or_mail_from)
            else:
                self.set('source_hostname', source_hostname_or_mail_from)

        event_source_hostname = self.get('dvchost', '')
        if event_source_hostname:
            try:
                dvchost = event_source_hostname.split('.', 1)[1]
                self.set('dvchost', dvchost)
            except:
                pass

    def _parse_extra(self, label_value):
        try:
            o_type, garb, rest = label_value.split(' - ', 2)
            self.set('o_type', o_type)
        except ValueError:
            return

        match = key_value_regex.finditer('%s,/n' % rest[1:-5])
        if not match:
            return
        try:
            for m in match:
                if not m.group(2).strip('"'):
                    continue
                self.set(m.group(1), m.group(2).strip('"'))
        except:
            pass

    def _set_library_columns(self):
        replace_info = trendmicro_apex_central_events.get(self.get('signature_id'))
        try:
            if replace_info:
                self.set('event_map_context', replace_info.get('Context'))
                self.set('event_map_type', replace_info.get('Type'))
                self.set('event_map_sub_type', replace_info.get('SubType'))
                self.set('LogType', replace_info.get('LogType'))
        except:
            pass

    def _extra_mapping(self):
        replace_info = replace_list.get(self.get('LogType', ''), {})
        for item, val in replace_info.items():
            try:
                if not self.get(item):
                    continue
                replace_column = val['ReplaceColumns'].get(str(self[item]), self[item])
                if item == 'Policy':
                    self.set('policy_name', replace_column)
                    continue
                self.set(item, replace_column)
            except:
                pass

    def _set_mandatory_fields(self):
        self.set('vendor_id', 1)
        self.set('event_source_product', PRODUCT_NAME)
        self.set('vendor_name', VENDOR_NAME)
        self.set('prefix_id', PREFIX_ID)
        self.set('system_id', ''.join([str(PREFIX_ID), str(self.get('vendor_id').get())]))
        self.set('event_source_ip', self.extra_info.get("EventSourceIP", '0.0.0.0'))
        self.set('event_source_type', 'Security System')
        self.set('event_source_category', 'Security Manager')
